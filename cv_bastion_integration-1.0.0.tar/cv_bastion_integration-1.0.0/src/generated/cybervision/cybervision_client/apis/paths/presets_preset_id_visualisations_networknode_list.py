from cybervision_client.paths.presets_preset_id_visualisations_networknode_list.get import ApiForget


class PresetsPresetIdVisualisationsNetworknodeList(
    ApiForget,
):
    pass
