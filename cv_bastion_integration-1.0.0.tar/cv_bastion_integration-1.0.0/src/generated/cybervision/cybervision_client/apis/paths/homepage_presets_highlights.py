from cybervision_client.paths.homepage_presets_highlights.get import ApiForget


class HomepagePresetsHighlights(
    ApiForget,
):
    pass
