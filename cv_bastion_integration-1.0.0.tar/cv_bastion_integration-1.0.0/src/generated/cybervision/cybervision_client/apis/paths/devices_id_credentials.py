from cybervision_client.paths.devices_id_credentials.get import ApiForget


class DevicesIdCredentials(
    ApiForget,
):
    pass
