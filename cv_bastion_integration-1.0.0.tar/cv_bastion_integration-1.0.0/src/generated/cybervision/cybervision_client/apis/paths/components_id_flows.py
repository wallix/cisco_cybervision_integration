from cybervision_client.paths.components_id_flows.get import ApiForget


class ComponentsIdFlows(
    ApiForget,
):
    pass
