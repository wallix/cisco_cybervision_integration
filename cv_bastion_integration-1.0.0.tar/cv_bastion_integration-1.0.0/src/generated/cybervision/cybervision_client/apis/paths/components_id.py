from cybervision_client.paths.components_id.get import ApiForget


class ComponentsId(
    ApiForget,
):
    pass
