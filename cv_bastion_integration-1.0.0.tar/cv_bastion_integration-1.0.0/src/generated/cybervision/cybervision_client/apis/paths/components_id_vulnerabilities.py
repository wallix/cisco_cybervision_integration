from cybervision_client.paths.components_id_vulnerabilities.get import ApiForget


class ComponentsIdVulnerabilities(
    ApiForget,
):
    pass
