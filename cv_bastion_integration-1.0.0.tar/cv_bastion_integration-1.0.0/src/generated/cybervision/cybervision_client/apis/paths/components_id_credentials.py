from cybervision_client.paths.components_id_credentials.get import ApiForget


class ComponentsIdCredentials(
    ApiForget,
):
    pass
