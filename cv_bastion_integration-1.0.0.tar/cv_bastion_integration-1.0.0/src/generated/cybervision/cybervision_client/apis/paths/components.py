from cybervision_client.paths.components.get import ApiForget


class Components(
    ApiForget,
):
    pass
