from cybervision_client.paths.presets_preset_id_visualisations_component_list.get import ApiForget


class PresetsPresetIdVisualisationsComponentList(
    ApiForget,
):
    pass
