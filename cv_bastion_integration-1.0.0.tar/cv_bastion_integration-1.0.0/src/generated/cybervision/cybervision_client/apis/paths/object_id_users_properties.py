from cybervision_client.paths.object_id_users_properties.post import ApiForpost


class ObjectIdUsersProperties(
    ApiForpost,
):
    pass
