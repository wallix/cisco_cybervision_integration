from cybervision_client.paths.components_id_flows_tags.get import ApiForget


class ComponentsIdFlowsTags(
    ApiForget,
):
    pass
