from cybervision_client.paths.presets_preset_id_settings.get import ApiForget


class PresetsPresetIdSettings(
    ApiForget,
):
    pass
