from cybervision_client.paths.devices_id_activities.get import ApiForget


class DevicesIdActivities(
    ApiForget,
):
    pass
