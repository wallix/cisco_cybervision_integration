from cybervision_client.paths.presets_preset_id.get import ApiForget


class PresetsPresetId(
    ApiForget,
):
    pass
