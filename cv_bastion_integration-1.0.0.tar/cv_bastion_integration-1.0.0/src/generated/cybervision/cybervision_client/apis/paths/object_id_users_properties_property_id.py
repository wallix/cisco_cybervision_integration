from cybervision_client.paths.object_id_users_properties_property_id.put import ApiForput
from cybervision_client.paths.object_id_users_properties_property_id.delete import ApiFordelete


class ObjectIdUsersPropertiesPropertyId(
    ApiForput,
    ApiFordelete,
):
    pass
