from cybervision_client.paths.components_id_variables.get import ApiForget


class ComponentsIdVariables(
    ApiForget,
):
    pass
