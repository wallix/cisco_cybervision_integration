from cybervision_client.paths.devices_id_risk_score.get import ApiForget


class DevicesIdRiskScore(
    ApiForget,
):
    pass
