from cybervision_client.paths.presets_preset_id_data_info.get import ApiForget


class PresetsPresetIdDataInfo(
    ApiForget,
):
    pass
