from cybervision_client.paths.devices_id_activities_tags.get import ApiForget


class DevicesIdActivitiesTags(
    ApiForget,
):
    pass
