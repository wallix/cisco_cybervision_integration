from cybervision_client.paths.devices_id_vulnerabilities.get import ApiForget


class DevicesIdVulnerabilities(
    ApiForget,
):
    pass
