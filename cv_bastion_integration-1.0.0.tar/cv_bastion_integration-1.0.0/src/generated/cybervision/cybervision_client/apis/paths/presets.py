from cybervision_client.paths.presets.get import ApiForget


class Presets(
    ApiForget,
):
    pass
