from cybervision_client.paths.object_id_label.post import ApiForpost
from cybervision_client.paths.object_id_label.delete import ApiFordelete


class ObjectIdLabel(
    ApiForpost,
    ApiFordelete,
):
    pass
