from cybervision_client.paths.devices_id_variables.get import ApiForget


class DevicesIdVariables(
    ApiForget,
):
    pass
