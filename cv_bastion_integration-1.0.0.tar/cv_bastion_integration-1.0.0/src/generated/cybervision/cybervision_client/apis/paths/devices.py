from cybervision_client.paths.devices.get import ApiForget


class Devices(
    ApiForget,
):
    pass
