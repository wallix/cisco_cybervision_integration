from bastion_client.paths.devices_device_id.get import ApiForget
from bastion_client.paths.devices_device_id.put import ApiForput


class DevicesDeviceId(
    ApiForget,
    ApiForput,
):
    pass
