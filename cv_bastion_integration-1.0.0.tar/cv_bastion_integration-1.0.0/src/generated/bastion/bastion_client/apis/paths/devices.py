from bastion_client.paths.devices.get import ApiForget
from bastion_client.paths.devices.post import ApiForpost


class Devices(
    ApiForget,
    ApiForpost,
):
    pass
